
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import ShoppingList from './components/ShoppingList';
import Analytics from './components/Analytics';
import { Product, Category, ProductStatus } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'list' | 'analytics'>('list');
  const [products, setProducts] = useState<Product[]>([]);

  // Local Storage Persistence
  useEffect(() => {
    const saved = localStorage.getItem('supersmart_products');
    if (saved) {
      try {
        setProducts(JSON.parse(saved));
      } catch (e) {
        console.error("Error loading products", e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('supersmart_products', JSON.stringify(products));
  }, [products]);

  // Phase 1: Planning (Adding from Home)
  const addProduct = (name: string, category: Category) => {
    const newProduct: Product = {
      id: crypto.randomUUID(),
      name,
      category,
      quantity: 1,
      unitPrice: 0,
      totalPrice: 0,
      status: 'pending',
      createdAt: Date.now()
    };
    setProducts(prev => [...prev, newProduct]);
  };

  // Phase 2: Buying (Updating in Supermarket)
  const updateProduct = (id: string, quantity: number, price: number, status: ProductStatus) => {
    setProducts(prev => prev.map(p => 
      p.id === id 
        ? { ...p, quantity, unitPrice: price, totalPrice: quantity * price, status } 
        : p
    ));
  };

  const removeProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const totalCollected = products.filter(p => p.status === 'collected').reduce((acc, p) => acc + p.totalPrice, 0);

  return (
    <Layout activeTab={activeTab} onTabChange={setActiveTab}>
      {activeTab === 'list' ? (
        <ShoppingList 
          products={products} 
          onAdd={addProduct} 
          onUpdate={updateProduct}
          onRemove={removeProduct} 
        />
      ) : (
        <Analytics products={products} />
      )}

      {/* Persistent Footer Stats */}
      {activeTab === 'list' && products.some(p => p.status === 'collected') && (
        <div className="fixed bottom-0 left-0 right-0 flex justify-center px-4 pb-4 pointer-events-none">
          <div className="w-full max-w-2xl bg-slate-800/95 backdrop-blur-2xl border border-slate-700/50 p-4 rounded-3xl flex justify-between items-center shadow-2xl pointer-events-auto ring-1 ring-white/5">
            <div className="flex flex-col">
              <span className="text-[9px] text-slate-400 font-black uppercase tracking-[0.2em]">Gastado</span>
              <span className="text-xl sm:text-2xl font-black text-emerald-400 tracking-tighter">
                ${totalCollected.toLocaleString()}
              </span>
            </div>
            <button 
              onClick={() => {
                if (confirm('¿Finalizar compras y vaciar lista?')) setProducts([]);
              }}
              className="bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-black transition-all shadow-lg shadow-emerald-500/20 active:scale-95"
            >
              FINALIZAR
            </button>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default App;
