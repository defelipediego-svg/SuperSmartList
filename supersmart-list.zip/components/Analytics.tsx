
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { Product } from '../types';
import { CATEGORIES, CATEGORY_COLORS } from '../constants';

interface AnalyticsProps {
  products: Product[];
}

const Analytics: React.FC<AnalyticsProps> = ({ products }) => {
  const boughtProducts = products.filter(p => p.status === 'collected');

  const data = CATEGORIES.map(cat => {
    const total = boughtProducts
      .filter(p => p.category === cat)
      .reduce((acc, p) => acc + p.totalPrice, 0);
    return {
      name: cat,
      value: total,
      color: CATEGORY_COLORS[cat]
    };
  }).filter(d => d.value > 0);

  const totalSpent = data.reduce((acc, d) => acc + d.value, 0);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-800 border border-slate-700 p-3 rounded-xl shadow-2xl ring-1 ring-white/10">
          <p className="text-slate-100 font-black text-xs uppercase tracking-wider">{payload[0].name}</p>
          <p className="text-emerald-400 font-black text-lg">${payload[0].value.toLocaleString()}</p>
          <p className="text-slate-400 text-[10px]">{((payload[0].value / totalSpent) * 100).toFixed(1)}% del total</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 sm:space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <section className="bg-slate-800/50 p-6 rounded-3xl border border-slate-700/50 shadow-xl text-center backdrop-blur-sm">
        <h2 className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em] mb-1">Gasto Real Carrito</h2>
        <p className="text-4xl sm:text-5xl font-black text-emerald-400 tracking-tighter">${totalSpent.toLocaleString()}</p>
        <div className="flex justify-center gap-2 mt-2">
          <span className="text-slate-500 text-[10px] font-bold uppercase">{boughtProducts.length} comprados</span>
          <span className="text-slate-700">•</span>
          <span className="text-slate-500 text-[10px] font-bold uppercase">{products.length} planeados</span>
        </div>
      </section>

      {data.length > 0 ? (
        <>
          <section className="bg-slate-800/40 p-4 sm:p-6 rounded-3xl border border-slate-700/50 shadow-lg h-[350px] sm:h-[400px]">
            <h3 className="text-sm font-black uppercase tracking-widest mb-2 text-slate-300">Gastos por Categoría</h3>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="45%"
                  innerRadius="50%"
                  outerRadius="75%"
                  paddingAngle={8}
                  dataKey="value"
                  animationBegin={0}
                  animationDuration={1500}
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend 
                  iconType="circle" 
                  layout="horizontal" 
                  verticalAlign="bottom" 
                  align="center"
                  wrapperStyle={{ fontSize: '10px', paddingTop: '10px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </section>

          <section className="space-y-3">
            <h3 className="text-xs font-black uppercase tracking-widest text-slate-500 px-1">Detalle</h3>
            <div className="grid gap-2">
              {data.sort((a, b) => b.value - a.value).map((item) => (
                <div key={item.name} className="bg-slate-800/30 p-4 rounded-2xl border border-slate-700/30 flex justify-between items-center transition-all hover:bg-slate-800/60">
                  <div className="flex items-center gap-3">
                    <div className="w-2.5 h-2.5 rounded-full ring-4 ring-white/5" style={{ backgroundColor: item.color }} />
                    <span className="text-xs font-bold text-slate-300">{item.name}</span>
                  </div>
                  <div className="text-right">
                    <p className="font-black text-sm text-slate-100">${item.value.toLocaleString()}</p>
                    <p className="text-[10px] font-bold text-slate-600">{((item.value / totalSpent) * 100).toFixed(1)}%</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </>
      ) : (
        <div className="text-center py-20 bg-slate-800/20 rounded-3xl border border-dashed border-slate-700/50">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 mx-auto text-slate-700 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
          </svg>
          <p className="text-slate-600 text-xs px-10 uppercase font-bold tracking-wider leading-relaxed">Sin datos para mostrar.<br/>Ingresa productos al carrito.</p>
        </div>
      )}
    </div>
  );
};

export default Analytics;
