
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: 'list' | 'analytics';
  onTabChange: (tab: 'list' | 'analytics') => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange }) => {
  return (
    <div className="min-h-screen flex flex-col w-full max-w-2xl mx-auto bg-slate-900 shadow-2xl overflow-x-hidden relative">
      <header className="bg-slate-800/80 backdrop-blur-lg border-b border-slate-700 sticky top-0 z-50 px-4 sm:px-6 py-3 sm:py-4 flex justify-between items-center">
        <div className="flex flex-col">
          <h1 className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent leading-tight">
            SuperSmart List
          </h1>
          <p className="text-slate-400 text-[10px] sm:text-xs">Gestión inteligente de compras</p>
        </div>
        <div className="flex gap-1 sm:gap-2">
          <button 
            onClick={() => onTabChange('list')}
            className={`p-2 rounded-xl transition-all ${activeTab === 'list' ? 'bg-emerald-500/20 text-emerald-400' : 'text-slate-400 hover:text-slate-200'}`}
            aria-label="Lista de compras"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 sm:h-6 sm:w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012-2" />
            </svg>
          </button>
          <button 
            onClick={() => onTabChange('analytics')}
            className={`p-2 rounded-xl transition-all ${activeTab === 'analytics' ? 'bg-emerald-500/20 text-emerald-400' : 'text-slate-400 hover:text-slate-200'}`}
            aria-label="Estadísticas"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 sm:h-6 sm:w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          </button>
        </div>
      </header>

      <main className="flex-1 pb-32">
        {children}
      </main>
    </div>
  );
};

export default Layout;
