
import React, { useState, useEffect } from 'react';
import { Product, Category } from '../types';
import { CATEGORIES, CATEGORY_COLORS } from '../constants';
import { getSmartCategorization, getShoppingTips } from '../services/geminiService';

interface ShoppingListProps {
  products: Product[];
  onAdd: (name: string, category: Category) => void;
  onUpdate: (id: string, quantity: number, price: number, status: 'collected' | 'pending') => void;
  onRemove: (id: string) => void;
}

const ShoppingList: React.FC<ShoppingListProps> = ({ products, onAdd, onUpdate, onRemove }) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<Category>('Almacén');
  const [isCategorizing, setIsCategorizing] = useState(false);
  const [tip, setTip] = useState<string>('');
  
  const [buyingId, setBuyingId] = useState<string | null>(null);
  const [buyingPrice, setBuyingPrice] = useState<number>(0);
  const [buyingQuantity, setBuyingQuantity] = useState<number>(1);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onAdd(name.trim(), category);
    setName('');
  };

  const handleSmartCategorize = async () => {
    if (!name || isCategorizing) return;
    setIsCategorizing(true);
    const suggested = await getSmartCategorization(name);
    setCategory(suggested);
    setIsCategorizing(false);
  };

  const startBuying = (product: Product) => {
    setBuyingId(product.id);
    setBuyingPrice(product.unitPrice || 0);
    setBuyingQuantity(product.quantity || 1);
  };

  const confirmPurchase = () => {
    if (buyingId) {
      onUpdate(buyingId, buyingQuantity, buyingPrice, 'collected');
      setBuyingId(null);
    }
  };

  const cancelPurchase = (id: string) => {
    onUpdate(id, 1, 0, 'pending');
  };

  useEffect(() => {
    const fetchTip = async () => {
      const pendingItems = products.filter(p => p.status === 'pending').map(p => p.name);
      if (pendingItems.length > 0) {
        const newTip = await getShoppingTips(pendingItems);
        setTip(newTip);
      }
    };
    fetchTip();
  }, [products.filter(p => p.status === 'pending').length]);

  const pendingProducts = products.filter(p => p.status === 'pending');
  const collectedProducts = products.filter(p => p.status === 'collected');
  const totalSpent = collectedProducts.reduce((acc, p) => acc + p.totalPrice, 0);

  return (
    <div className="p-4 sm:p-6 space-y-6 sm:space-y-8">
      {/* 1. Planning Phase */}
      <section className="bg-slate-800 p-4 sm:p-6 rounded-2xl border border-slate-700 shadow-xl">
        <div className="mb-3 sm:mb-4">
          <h2 className="text-lg sm:text-xl font-bold text-emerald-400 flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
            Paso 1: Armar Lista
          </h2>
          <p className="text-[11px] sm:text-xs text-slate-400">Desde casa: ¿Qué falta?</p>
        </div>
        <form onSubmit={handleAdd} className="space-y-3 sm:space-y-4">
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
            <div className="flex-1 relative">
              <input 
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                onBlur={handleSmartCategorize}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500 outline-none text-slate-100"
                placeholder="Nombre del producto..."
              />
              {isCategorizing && (
                <div className="absolute right-3 top-3.5">
                   <div className="w-4 h-4 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <select 
                value={category}
                onChange={(e) => setCategory(e.target.value as Category)}
                className="flex-1 sm:flex-none bg-slate-900 border border-slate-700 rounded-xl px-3 py-3 focus:ring-2 focus:ring-emerald-500 outline-none text-sm text-slate-200"
              >
                {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
              </select>
              <button 
                type="submit"
                className="bg-emerald-500 hover:bg-emerald-600 w-12 sm:w-14 rounded-xl flex items-center justify-center transition-all shadow-lg shadow-emerald-500/20 active:scale-95"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" />
                </svg>
              </button>
            </div>
          </div>
        </form>
      </section>

      {/* AI Tips */}
      {tip && pendingProducts.length > 0 && (
        <div className="bg-cyan-900/30 border border-cyan-700/50 p-3 sm:p-4 rounded-xl flex items-start gap-3 animate-pulse-once">
          <div className="bg-cyan-500 p-2 rounded-lg shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <p className="text-[11px] sm:text-sm text-cyan-200 leading-relaxed italic">"{tip}"</p>
        </div>
      )}

      {/* 2. Supermarket Phase */}
      <section className="space-y-3 sm:space-y-4">
        <h2 className="text-lg sm:text-xl font-bold text-slate-100 px-1 flex items-center gap-2">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
          </svg>
          Paso 2: Comprando
          <span className="text-[10px] font-bold text-slate-400 px-2 py-0.5 bg-slate-800 rounded-full">
            {pendingProducts.length} pendiente{pendingProducts.length !== 1 ? 's' : ''}
          </span>
        </h2>
        
        {pendingProducts.length === 0 ? (
          <div className="text-center py-6 bg-slate-800/20 rounded-2xl border border-dashed border-slate-700">
            <p className="text-slate-500 text-xs sm:text-sm">¡Listo! No quedan pendientes.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {pendingProducts.map(product => (
              <div key={product.id} className="bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden transition-all shadow-sm">
                {buyingId === product.id ? (
                  <div className="p-4 bg-slate-700/30 space-y-4 animate-in fade-in zoom-in-95 duration-200">
                    <div className="flex justify-between items-center">
                      <h4 className="font-bold text-sm text-emerald-400 truncate pr-2">Añadir: {product.name}</h4>
                      <button onClick={() => setBuyingId(null)} className="p-1 text-slate-400 hover:text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                      </button>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[9px] text-slate-400 uppercase font-black mb-1 tracking-wider">Precio Unit.</label>
                        <input 
                          type="number" 
                          autoFocus
                          inputMode="decimal"
                          value={buyingPrice || ''}
                          onChange={e => setBuyingPrice(Number(e.target.value))}
                          className="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2 text-sm text-slate-100 outline-none focus:ring-2 focus:ring-emerald-500"
                          placeholder="$ 0.00"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] text-slate-400 uppercase font-black mb-1 tracking-wider">Cantidad</label>
                        <input 
                          type="number" 
                          inputMode="numeric"
                          value={buyingQuantity}
                          onChange={e => setBuyingQuantity(Number(e.target.value))}
                          className="w-full bg-slate-900 border border-slate-600 rounded-xl px-3 py-2 text-sm text-slate-100 outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>
                    </div>
                    <button 
                      onClick={confirmPurchase}
                      className="w-full bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-black py-3 rounded-xl shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
                    >
                      OK, AL CARRITO
                    </button>
                  </div>
                ) : (
                  <div className="p-3 sm:p-4 flex justify-between items-center">
                    <div className="flex items-center gap-3 overflow-hidden">
                      <div className="w-1 h-8 rounded-full shrink-0" style={{ backgroundColor: CATEGORY_COLORS[product.category] }} />
                      <div className="overflow-hidden">
                        <h3 className="text-sm font-semibold text-slate-100 truncate">{product.name}</h3>
                        <span className="text-[9px] text-slate-500 uppercase tracking-widest font-bold">{product.category}</span>
                      </div>
                    </div>
                    <div className="flex gap-1.5 shrink-0">
                      <button 
                        onClick={() => startBuying(product)}
                        className="bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-white px-4 py-2 rounded-xl text-xs font-black transition-all border border-emerald-500/20 active:scale-90"
                      >
                        RECOGER
                      </button>
                      <button 
                        onClick={() => onRemove(product.id)}
                        className="p-2 text-slate-600 hover:text-red-400 transition-colors"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 3. Cart Phase */}
      <section className="space-y-4 pt-4 border-t border-slate-800">
        <div className="flex justify-between items-center px-1">
          <h2 className="text-lg sm:text-xl font-bold text-slate-100 flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-emerald-500" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 2a4 4 0 00-4 4v1H5a1 1 0 00-.994.89l-1 9A1 1 0 004 18h12a1 1 0 00.994-1.11l-1-9A1 1 0 0015 7h-1V6a4 4 0 00-4-4zm2 5V6a2 2 0 10-4 0v1h4zm-6 3a1 1 0 112 0 1 1 0 01-2 0zm7-1a1 1 0 100 2 1 1 0 000-2z" clipRule="evenodd" />
            </svg>
            En el Carrito
          </h2>
          <span className="text-sm font-bold text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
            {collectedProducts.length}
          </span>
        </div>

        {collectedProducts.length === 0 ? (
          <div className="text-center py-6 bg-slate-800/10 rounded-2xl border border-dashed border-slate-800/50">
            <p className="text-slate-600 text-xs italic uppercase tracking-tighter">Carrito vacío</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {collectedProducts.map(product => (
              <div key={product.id} className="bg-slate-900/40 p-3 rounded-xl border border-slate-800 flex justify-between items-center group active:bg-slate-800/50">
                <div className="flex items-center gap-3 overflow-hidden">
                   <div className="bg-emerald-500/20 p-1.5 rounded-lg">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-emerald-500" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                   </div>
                  <div className="overflow-hidden">
                    <h3 className="text-xs font-semibold text-slate-300 line-through decoration-slate-600/50 truncate">{product.name}</h3>
                    <p className="text-[10px] text-slate-500 font-medium">{product.quantity} x ${product.unitPrice}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-sm font-black text-slate-200">${product.totalPrice.toLocaleString()}</span>
                  <button 
                    onClick={() => cancelPurchase(product.id)}
                    className="p-2 text-slate-600 hover:text-slate-300 active:scale-90 transition-all"
                    title="Devolver a pendientes"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" />
                    </svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};

export default ShoppingList;
