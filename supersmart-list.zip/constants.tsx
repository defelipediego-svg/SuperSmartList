
import { Category } from './types';

export const CATEGORIES: Category[] = [
  'Carnes',
  'Lácteos',
  'Panificación',
  'Frutas/Verduras',
  'Limpieza',
  'Almacén',
  'Bebidas',
  'Otros'
];

export const CATEGORY_COLORS: Record<Category, string> = {
  'Carnes': '#ef4444', // red-500
  'Lácteos': '#3b82f6', // blue-500
  'Panificación': '#f59e0b', // amber-500
  'Frutas/Verduras': '#10b981', // emerald-500
  'Limpieza': '#a855f7', // purple-500
  'Almacén': '#6366f1', // indigo-500
  'Bebidas': '#06b6d4', // cyan-500
  'Otros': '#64748b'    // slate-500
};
