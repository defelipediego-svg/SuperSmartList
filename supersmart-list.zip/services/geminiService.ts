
import { GoogleGenAI, Type } from "@google/genai";
import { Category } from "../types";
import { CATEGORIES } from "../constants";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getSmartCategorization = async (productName: string): Promise<Category> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Categoriza el siguiente producto de supermercado: "${productName}". 
      Responde SOLO con una de estas categorías: ${CATEGORIES.join(', ')}.`,
      config: {
        maxOutputTokens: 20,
        temperature: 0.1,
      },
    });

    const categoryText = response.text?.trim() as Category;
    if (CATEGORIES.includes(categoryText)) {
      return categoryText;
    }
    return 'Otros';
  } catch (error) {
    console.error("Gemini Error:", error);
    return 'Otros';
  }
};

export const getShoppingTips = async (items: string[]): Promise<string> => {
  if (items.length === 0) return "Agrega productos para recibir consejos inteligentes.";
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Tengo estos productos en mi lista de compras: ${items.join(', ')}. 
      Dime en dos frases cortas qué me podría faltar o un consejo de ahorro relevante.`,
      config: {
        maxOutputTokens: 100,
      }
    });
    return response.text || "No se pudo obtener consejo.";
  } catch (error) {
    return "Continúa con tus compras!";
  }
};
