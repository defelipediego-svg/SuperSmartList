
export type Category = 
  | 'Carnes' 
  | 'Lácteos' 
  | 'Panificación' 
  | 'Frutas/Verduras' 
  | 'Limpieza' 
  | 'Almacén' 
  | 'Bebidas' 
  | 'Otros';

export type ProductStatus = 'pending' | 'collected';

export interface Product {
  id: string;
  name: string;
  category: Category;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  status: ProductStatus;
  createdAt: number;
}

export interface CategoryExpense {
  name: string;
  value: number;
  color: string;
}
